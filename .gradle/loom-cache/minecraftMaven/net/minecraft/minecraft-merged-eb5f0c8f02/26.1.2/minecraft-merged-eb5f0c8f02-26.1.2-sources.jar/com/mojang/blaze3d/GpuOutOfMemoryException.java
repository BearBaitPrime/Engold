/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.blaze3d;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class GpuOutOfMemoryException
extends RuntimeException {
    public GpuOutOfMemoryException(String message) {
        super(message);
    }
}

