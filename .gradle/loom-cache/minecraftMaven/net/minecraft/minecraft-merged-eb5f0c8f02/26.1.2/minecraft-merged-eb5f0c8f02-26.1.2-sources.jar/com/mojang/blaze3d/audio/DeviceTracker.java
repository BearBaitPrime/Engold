/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.blaze3d.audio;

import com.mojang.blaze3d.audio.DeviceList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public interface DeviceTracker {
    public DeviceList currentDevices();

    public void tick();

    public void forceRefresh();
}

