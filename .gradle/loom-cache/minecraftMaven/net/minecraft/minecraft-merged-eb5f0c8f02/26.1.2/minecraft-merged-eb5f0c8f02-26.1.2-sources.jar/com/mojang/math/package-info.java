/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
@NullMarked
package com.mojang.math;

import org.jspecify.annotations.NullMarked;


