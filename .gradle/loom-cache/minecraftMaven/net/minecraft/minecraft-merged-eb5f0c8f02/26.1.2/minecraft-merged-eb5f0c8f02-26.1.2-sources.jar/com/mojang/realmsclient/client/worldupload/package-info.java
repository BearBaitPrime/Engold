/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
@NullMarked
@Environment(value=EnvType.CLIENT)
package com.mojang.realmsclient.client.worldupload;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.NullMarked;


