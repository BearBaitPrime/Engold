/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.realmsclient.dto;

import com.google.gson.annotations.SerializedName;
import com.mojang.realmsclient.dto.ReflectionBasedSerialization;
import com.mojang.realmsclient.dto.RegionPingResult;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public record PingResult(@SerializedName(value="pingResults") List<RegionPingResult> pingResults, @SerializedName(value="worldIds") List<Long> realmIds) implements ReflectionBasedSerialization
{
    @SerializedName(value="pingResults")
    public List<RegionPingResult> pingResults() {
        return this.pingResults;
    }

    @SerializedName(value="worldIds")
    public List<Long> realmIds() {
        return this.realmIds;
    }
}

