/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.realmsclient.dto;

import com.google.gson.annotations.SerializedName;
import com.mojang.realmsclient.dto.ReflectionBasedSerialization;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public record RealmsWorldResetDto(@SerializedName(value="seed") String seed, @SerializedName(value="worldTemplateId") long worldTemplateId, @SerializedName(value="levelType") int levelType, @SerializedName(value="generateStructures") boolean generateStructures, @SerializedName(value="experiments") Set<String> experiments) implements ReflectionBasedSerialization
{
    @SerializedName(value="seed")
    public String seed() {
        return this.seed;
    }

    @SerializedName(value="worldTemplateId")
    public long worldTemplateId() {
        return this.worldTemplateId;
    }

    @SerializedName(value="levelType")
    public int levelType() {
        return this.levelType;
    }

    @SerializedName(value="generateStructures")
    public boolean generateStructures() {
        return this.generateStructures;
    }

    @SerializedName(value="experiments")
    public Set<String> experiments() {
        return this.experiments;
    }
}

