/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.realmsclient.util.task;

import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.RealmsMainScreen;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.exception.RetryCallException;
import com.mojang.realmsclient.gui.screens.configuration.RealmsConfigureWorldScreen;
import com.mojang.realmsclient.util.task.LongRunningTask;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;

@Environment(value=EnvType.CLIENT)
public class OpenServerTask
extends LongRunningTask {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Component TITLE = Component.translatable("mco.configure.world.opening");
    private final RealmsServer serverData;
    private final Screen returnScreen;
    private final boolean join;
    private final Minecraft minecraft;

    public OpenServerTask(RealmsServer realmsServer, Screen returnScreen, boolean join, Minecraft minecraft) {
        this.serverData = realmsServer;
        this.returnScreen = returnScreen;
        this.join = join;
        this.minecraft = minecraft;
    }

    @Override
    public void run() {
        RealmsClient client = RealmsClient.getOrCreate();
        for (int i = 0; i < 25; ++i) {
            if (this.aborted()) {
                return;
            }
            try {
                boolean openResult = client.open(this.serverData.id);
                if (!openResult) continue;
                this.minecraft.execute(() -> {
                    Screen patt0$temp = this.returnScreen;
                    if (patt0$temp instanceof RealmsConfigureWorldScreen) {
                        RealmsConfigureWorldScreen screen = (RealmsConfigureWorldScreen)patt0$temp;
                        screen.stateChanged();
                    }
                    this.serverData.state = RealmsServer.State.OPEN;
                    if (this.join) {
                        RealmsMainScreen.play(this.serverData, this.returnScreen);
                    } else {
                        this.minecraft.setScreen(this.returnScreen);
                    }
                });
                break;
            } catch (RetryCallException e) {
                if (this.aborted()) {
                    return;
                }
                OpenServerTask.pause(e.delaySeconds);
                continue;
            } catch (Exception e) {
                if (this.aborted()) {
                    return;
                }
                LOGGER.error("Failed to open server", e);
                this.error(e);
            }
        }
    }

    @Override
    public Component getTitle() {
        return TITLE;
    }
}

