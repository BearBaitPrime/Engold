/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft;

import java.util.concurrent.Callable;

public interface CrashReportDetail<V>
extends Callable<V> {
}

