/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.advancements;

import net.minecraft.world.level.storage.loot.ValidationContextSource;

public interface CriterionTriggerInstance {
    public void validate(ValidationContextSource var1);
}

